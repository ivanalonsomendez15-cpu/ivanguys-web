@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo ERROR: No se encuentra el compilador C# integrado en .NET Framework.
 echo Comprueba que tienes Windows 11 y .NET Framework 4.8 activado.
 pause
 exit /b 1
)
if not exist "SIM_TURBO_PC.exe" goto build
goto run
:build
echo Compilando programa Windows localmente. No se descarga nada.
"%CSC%" /nologo /target:winexe /optimize+ /out:"SIM_TURBO_PC.exe" /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll "SIM_TURBO_PC.cs"
if errorlevel 1 (
 echo Error al compilar. Revisa el mensaje anterior.
 pause
 exit /b 1
)
:run
start "SIM TURBO PC" "%~dp0SIM_TURBO_PC.exe"
exit /b 0
