package com.simturbopc.ultra;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.SocketTimeoutException;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Telemetría Wi-Fi local y voluntaria. No envía datos de la SIM ni crea un hotspot. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF09101E, CARD = 0xFF18263B, CYAN = 0xFF19D9D1, WHITE = 0xFFF2F7FE, GREY = 0xFFB2C4D8;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private EditText ipBox, codeBox;
    private TextView status, stats;
    private Button toggle, cellularToggle;
    private TextView cellStatus;
    private volatile boolean cellularOn = false;
    private volatile Network cellNetwork;
    private volatile String pairedPcIp = "", pairedToken = "";
    private ServerSocket cellServer;
    private BondedServer bondedServer;
    private ConnectivityManager.NetworkCallback cellularCallback;
    private final AtomicLong simBytes = new AtomicLong(0L);
    private boolean active = false;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!active) return;
            sendOnce();
            handler.postDelayed(this, 2500);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(30), dp(20), dp(32));
        sv.addView(root);

        root.addView(text("SIM TURBO", 34, WHITE, true));
        root.addView(text("PC ULTRA  ·  HYPERLINK ANDROID V4", 12, CYAN, true));
        gap(root, 26);
        root.addView(text("Enlace inalámbrico: medidor Wi-Fi + puente celular opcional", 16, WHITE, true));
        gap(root, 11);
        root.addView(text("El PC conserva su Wi-Fi. Este móvil envía mediciones y, si activas la SIM, descarga fragmentos HTTPS que el PC reúne con otros descargados por Wi-Fi. No necesita USB ni activar el punto de acceso.", 14, GREY, false));
        gap(root, 22);

        LinearLayout form = card(); root.addView(form);
        form.addView(text("EMPAREJAR CON EL PC", 15, CYAN, true));
        gap(form, 13);
        form.addView(text("Dirección IPv4 que aparece en Windows", 12, GREY, false));
        ipBox = entry("Ej.: 192.168.1.34"); form.addView(ipBox);
        gap(form, 12);
        form.addView(text("Código de 10 caracteres de Windows", 12, GREY, false));
        codeBox = entry("Ej.: A1B2C3D4E5"); form.addView(codeBox);
        gap(form, 15);
        toggle = new Button(this); toggle.setAllCaps(false); toggle.setText("CONECTAR Y MEDIR");
        toggle.setTextColor(BG); toggle.setTextSize(15); toggle.setTypeface(null, Typeface.BOLD);
        toggle.setBackground(rounded(CYAN, 14)); form.addView(toggle,
            new LinearLayout.LayoutParams(-1, dp(55)));
        toggle.setOnClickListener(v -> { if(active) stop(); else start(); });
        gap(root, 20);

        LinearLayout readings = card(); root.addView(readings);
        readings.addView(text("LECTURAS DEL MÓVIL", 15, CYAN, true));
        gap(readings, 14);
        stats = text("Sin datos todavía", 15, WHITE, false); readings.addView(stats);
        gap(readings, 10);
        status = text("Estado: desconectado", 13, GREY, false); readings.addView(status);
        gap(root, 18);
        LinearLayout cellCard = card(); root.addView(cellCard);
        cellCard.addView(text("MODO 2 · SIM REAL PARA SUMAR DESCARGAS", 15, CYAN, true));
        gap(cellCard, 10);
        cellCard.addView(text("AVISO: al activarlo se consumen datos de tu tarifa 4G/5G. Puede tener costes y calentamiento. Necesitas Wi-Fi y datos activos al mismo tiempo. La app debe permanecer abierta.", 14, GREY, false));
        gap(cellCard, 12);
        cellularToggle = new Button(this); cellularToggle.setAllCaps(false);
        cellularToggle.setText("ACTIVAR PUENTE SIM"); cellularToggle.setTextColor(BG);
        cellularToggle.setTypeface(null,Typeface.BOLD); cellularToggle.setBackground(rounded(CYAN,14));
        cellCard.addView(cellularToggle,new LinearLayout.LayoutParams(-1,dp(52)));
        gap(cellCard,8);
        cellStatus = text("Inactivo: 0 bytes transferidos por el puente.",13,GREY,false);
        cellCard.addView(cellStatus);
        cellularToggle.setOnClickListener(v -> { if(cellularOn) stopCell(); else startCell(); });
        gap(root, 18);
        root.addView(text("PRIVACIDAD Y LÍMITES", 12, CYAN, true));
        gap(root, 8);
        root.addView(text("• Telemetría Wi-Fi sin ubicación GPS, SSID ni contraseñas.\n• El puente SIM es opcional: solo abre conexiones HTTPS (puerto 443) solicitadas desde el PC emparejado, con código local.\n• El tráfico entre PC y móvil viaja por la red doméstica; usa Wi-Fi de confianza.\n• La SIM consume datos. La suma V4 sirve para archivos HTTPS con rangos, no acelera todos los juegos ni Windows.\n• Se detiene al salir de la app. No desactiva ningún cortafuegos.", 13, GREY, false));
        setContentView(sv);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, 203);
    }

    private void start() {
        final String ip = ipBox.getText().toString().trim();
        final String code = codeBox.getText().toString().trim().toUpperCase(Locale.ROOT);
        if (!ip.matches("[0-9.]{7,15}") || !code.matches("[0-9A-F]{10}")) {
            status.setText("Introduce una IP local IPv4 válida y el código del PC (10 caracteres)."); return;
        }
        try {
            InetAddress addr = InetAddress.getByName(ip);
            if (!addr.isSiteLocalAddress()) { status.setText("Por seguridad, solo direcciones privadas del hogar (LAN)."); return; }
        } catch (Exception ex) { status.setText("La dirección IP no es válida."); return; }
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (findWifi(cm) == null) { status.setText("Conecta este móvil al mismo Wi-Fi que el PC."); return; }
        pairedPcIp = ip; pairedToken = code;
        active = true; toggle.setText("DESCONECTAR");
        toggle.setBackground(rounded(0xFFFE8196, 14));
        ipBox.setEnabled(false); codeBox.setEnabled(false);
        status.setText("Enviando por Wi-Fi local cada 2,5 segundos...");
        handler.post(tick);
    }
    private void stop() {
        stopCell();
        active = false; handler.removeCallbacks(tick);
        toggle.setText("CONECTAR Y MEDIR"); toggle.setBackground(rounded(CYAN, 14));
        ipBox.setEnabled(true); codeBox.setEnabled(true);
        status.setText("Desconectado. No se están enviando datos.");
    }
    @Override protected void onStop() { stop(); super.onStop(); }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); super.onDestroy(); }

    private Network findWifi(ConnectivityManager cm) {
        if (cm == null) return null;
        for (Network n : cm.getAllNetworks()) {
            NetworkCapabilities cap = cm.getNetworkCapabilities(n);
            if (cap != null && cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n;
        }
        return null;
    }
    private void sendOnce() {
        WifiManager wifi = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi == null ? null : wifi.getConnectionInfo();
        int rssi = info == null ? -127 : info.getRssi();
        int freq = info == null ? 0 : info.getFrequency();
        int rate = info == null ? 0 : Math.max(0,info.getLinkSpeed());
        stats.setText("Señal: " + rssi + " dBm\nFrecuencia: " + freq + " MHz\nEnlace del móvil: " + rate + " Mb/s (no es Internet)");
        final String ip = ipBox.getText().toString().trim();
        final String code = codeBox.getText().toString().trim().toUpperCase(Locale.ROOT);
        final String packet = "STPC2|" + code + "|" + rssi + "|" + freq + "|" + rate;
        new Thread(() -> {
            try {
                ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                Network network = findWifi(cm);
                if (network == null) throw new Exception("No hay conexión Wi-Fi");
                try (DatagramSocket s = new DatagramSocket()) {
                    network.bindSocket(s); // No utiliza la SIM ni los datos móviles.
                    byte[] b = packet.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket datagram = new DatagramPacket(b,b.length,InetAddress.getByName(ip),45721);
                    s.send(datagram);
                }
                runOnUiThread(() -> { if(active) status.setText("Mediciones enviadas por Wi-Fi al PC. Comprueba Windows."); });
            } catch (Exception e) {
                final String error = e.getMessage();
                runOnUiThread(() -> { if(active) status.setText("Envío fallido: " + error + ". Revisa IP y firewall privado."); });
            }
        }).start();
    }

    private void startCell() {
        if(!active) {cellStatus.setText("Primero pulsa CONECTAR Y MEDIR y empareja el PC.");return;}
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(findWifi(cm)==null) {cellStatus.setText("El Wi-Fi local debe estar conectado.");return;}
        new android.app.AlertDialog.Builder(this)
          .setTitle("Autorizar consumo de datos SIM")
          .setMessage("Esta función usa 4G/5G real y puede gastar muchos datos móviles de tu tarifa, además de batería. No duplica antenas ni garantiza velocidad. El PC podrá usarla para parte del tráfico web HTTPS mientras la app esté abierta. ¿Activar?")
          .setNegativeButton("Cancelar",(d,w)->{})
          .setPositiveButton("ACTIVAR",(d,w)->launchCell())
          .show();
    }
    private void launchCell() {
        if(cellularOn)return;
        cellularOn=true;
        cellularToggle.setText("DETENER PUENTE SIM");
        cellularToggle.setBackground(rounded(0xFFFE8196,14));
        cellStatus.setText("Pidiendo conexión celular a Android...");
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null){stopCell();return;}
        cellularCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                if(!cellularOn)return;
                cellNetwork=network;
                runOnUiThread(()->cellStatus.setText("SIM disponible. Puente TCP local en puerto 45725. Datos: "+simBytes.get()+" B"));
            }
            @Override public void onLost(Network network) {
                if(network.equals(cellNetwork)) { cellNetwork=null; runOnUiThread(()->cellStatus.setText("SIM sin acceso. Tráfico volverá al Wi-Fi del PC.")); }
            }
        };
        NetworkRequest request=new NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build();
        try {cm.requestNetwork(request,cellularCallback);} catch(Exception e) { cellStatus.setText("No se puede solicitar red celular: "+e.getMessage());stopCell();return; }
        bondedServer = new BondedServer(pairedPcIp, pairedToken,
            () -> cellNetwork,
            line -> { if(cellularOn)cellStatus.setText(line); });
        bondedServer.start();
        new Thread(()->{
            try(ServerSocket server=new ServerSocket()) {
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress("0.0.0.0",45725),8);
                cellServer=server;
                while(cellularOn) {
                    Socket incoming=server.accept();
                    new Thread(()->serveCell(incoming),"sim-turbo-relay").start();
                }
            } catch(Exception e) {
                if(cellularOn)runOnUiThread(()->cellStatus.setText("Error en puente local: "+e.getMessage()));
            } finally {cellServer=null;}
        },"sim-turbo-accept").start();
    }
    private void stopCell() {
        if(bondedServer!=null) {bondedServer.stop();bondedServer=null;}
        cellularOn=false;cellNetwork=null;
        try{if(cellServer!=null)cellServer.close();}catch(Exception ignored){}
        try {if(cellularCallback!=null) {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm!=null)cm.unregisterNetworkCallback(cellularCallback);
        }}catch(Exception ignored){}
        cellularCallback=null;
        if(cellularToggle!=null){cellularToggle.setText("ACTIVAR PUENTE SIM");cellularToggle.setBackground(rounded(CYAN,14));}
        if(cellStatus!=null) cellStatus.setText("Puente SIM detenido. Bytes contados: "+simBytes.get());
    }
    private static String readLine(InputStream in,int max) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        for(int n=0;n<max;n++){
            int c=in.read();if(c<0)throw new IOException("Sin cabecera");
            if(c=='\n') return b.toString("US-ASCII").trim();
            if(c!='\r')b.write(c);
        }
        throw new IOException("Mensaje demasiado largo");
    }
    private void serveCell(Socket incoming) {
        try(Socket pc=incoming){
            if(!cellularOn || !pc.getInetAddress().isSiteLocalAddress())return;
            String expectedIp=pairedPcIp;
            if(!pc.getInetAddress().getHostAddress().equals(expectedIp)) return;
            pc.setSoTimeout(15000);
            InputStream input=pc.getInputStream();OutputStream output=pc.getOutputStream();
            String line=readLine(input,900);
            String[] parts=line.split("\\|",4);
            if(parts.length!=4 || !parts[0].equals("STPC3") ||
                  !parts[1].equalsIgnoreCase(pairedToken) ||
                  !parts[2].matches("[A-Za-z0-9._-]{1,250}") || !parts[3].equals("443"))return;
            Network network=cellNetwork;
            if(network==null) { output.write("ERR\n".getBytes(StandardCharsets.US_ASCII));return;}
            InetAddress[] hosts=network.getAllByName(parts[2]);
            if(hosts.length==0)throw new IOException("No se resuelve el dominio");
            try(Socket remote=network.getSocketFactory().createSocket()) {
                remote.connect(new InetSocketAddress(hosts[0],443),7000);
                output.write("OK\n".getBytes(StandardCharsets.US_ASCII));output.flush();
                pc.setSoTimeout(0);
                Thread downstream=new Thread(()->pipeCount(remote,pc));
                downstream.setDaemon(true);downstream.start();
                pipeCount(pc,remote);
            }
        }catch(Exception ignored){}
    }
    private void pipeCount(Socket from,Socket to) {
        try {
            InputStream ins=from.getInputStream();OutputStream outs=to.getOutputStream();
            byte[] b=new byte[16384];int n;
            while(cellularOn && (n=ins.read(b))>0){outs.write(b,0,n);outs.flush();long used=simBytes.addAndGet(n);
                if(used%262144<n)runOnUiThread(()->{if(cellularOn)cellStatus.setText("Puente SIM activo · transferencia: "+(simBytes.get()/1048576.0)+" MiB");});
            }
        }catch(Exception ignored){}
    }

    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n+0.5f); }
    private void gap(LinearLayout x,int h) { View v = new View(this); x.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private GradientDrawable rounded(int color,int r) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(r)); return d;
    }
    private LinearLayout card() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(17),dp(18),dp(17),dp(20)); l.setBackground(rounded(CARD,17)); return l;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null,Typeface.BOLD); return v;
    }
    private EditText entry(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(16); e.setHint(hint);
        e.setTextColor(WHITE); e.setHintTextColor(0xFF7991A8); e.setPadding(dp(14),dp(12),dp(14),dp(12));
        e.setBackground(rounded(0xFF0B1526,10)); return e;
    }
}
