$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "PC_Windows")
$csc = "$env:WINDIR\Microsoft.NET\Framework644.0.30319\csc.exe"
if (!(Test-Path $csc)) { throw "Falta el compilador csc.exe de .NET Framework" }
$fuentes = (Get-ChildItem -Filter "*.cs" | Sort-Object Name).Name
& $csc /nologo /optimize+ /target:winexe /out:SIM_TURBO_PC_ULTRA_V16.exe /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Management.dll $fuentes
if ($LASTEXITCODE -ne 0) { throw "Error compilando C#" }
Write-Host "Compilación completa"
