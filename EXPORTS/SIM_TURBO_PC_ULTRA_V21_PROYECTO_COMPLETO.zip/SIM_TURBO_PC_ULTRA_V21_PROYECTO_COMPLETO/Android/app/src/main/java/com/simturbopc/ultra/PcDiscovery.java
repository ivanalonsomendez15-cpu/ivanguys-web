package com.simturbopc.ultra;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Locale;

/** Local, user-triggered UDP discovery. No token is broadcast. */
public final class PcDiscovery {
    private PcDiscovery(){}
    public static String capabilities(Context context,String host,String code) throws IOException {
        if(code==null||!code.matches("[0-9A-Fa-f]{10}"))
            throw new IOException("Introduce primero el código de emparejamiento");
        InetAddress ip=InetAddress.getByName(host);
        if(!ip.isSiteLocalAddress())throw new IOException("PC fuera de la LAN");
        ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network wifi=null;
        if(cm!=null)for(Network n:cm.getAllNetworks()){
            NetworkCapabilities cap=cm.getNetworkCapabilities(n);
            if(cap!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)){wifi=n;break;}
        }
        if(wifi==null)throw new IOException("Conecta el móvil por Wi-Fi");
        byte[] nonceBytes=new byte[8];
        new SecureRandom().nextBytes(nonceBytes);
        StringBuilder nonce=new StringBuilder();
        for(byte b:nonceBytes)nonce.append(String.format(Locale.ROOT,"%02X",b&255));
        String request="STPC-CAPS17|"+nonce+"|"+
            SecurePacketV17.sign(code,"CAPS17|"+nonce);
        try(DatagramSocket socket=new DatagramSocket()){
            wifi.bindSocket(socket);
            socket.setSoTimeout(2200);
            byte[] bytes=request.getBytes(StandardCharsets.US_ASCII);
            socket.send(new DatagramPacket(bytes,bytes.length,ip,45728));
            byte[] buffer=new byte[400];
            DatagramPacket response=new DatagramPacket(buffer,buffer.length);
            socket.receive(response);
            if(!response.getAddress().equals(ip))throw new IOException("Respuesta de otro equipo");
            String body=new String(buffer,0,response.getLength(),StandardCharsets.US_ASCII);
            String prefix="STPC-CAPS17-OK|"+nonce+"|";
            if(!body.startsWith(prefix))throw new IOException("Respuesta de emparejamiento no válida");
            String[] fields=body.substring(prefix.length()).split("\\|",4);
            if(fields.length!=4)throw new IOException("Respuesta incompleta");
            String signed=body.substring(0,body.lastIndexOf('|'));
            if(!SecurePacketV17.verify(code,signed,fields[3]))
                throw new IOException("Respuesta PC sin autenticación válida");
            return "CPU lógica: "+fields[0]+" · RAM: "+fields[1]+" · GPU: "+fields[2];
        }catch(java.net.SocketTimeoutException ex){
            throw new IOException("PC no respondió: abre el receptor y comprueba el código");
        }
    }

    public static String find(Context context) throws IOException {
        ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network wifi=null;
        if(cm!=null)for(Network n:cm.getAllNetworks()) {
            NetworkCapabilities c=cm.getNetworkCapabilities(n);
            if(c!=null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {wifi=n;break;}
        }
        if(wifi==null)throw new IOException("Conecta el móvil a la Wi-Fi del PC");
        byte[] bytes=new byte[8];
        new SecureRandom().nextBytes(bytes);
        StringBuilder token=new StringBuilder();
        for(byte b:bytes)token.append(String.format(Locale.ROOT,"%02X",b&255));
        String request="STPC-DISCOVER|"+token;
        try(DatagramSocket socket=new DatagramSocket()) {
            wifi.bindSocket(socket);
            socket.setBroadcast(true);
            socket.setSoTimeout(2200);
            byte[] query=request.getBytes(StandardCharsets.US_ASCII);
            socket.send(new DatagramPacket(query,query.length,
                InetAddress.getByName("255.255.255.255"),45728));
            long deadline=System.currentTimeMillis()+2200L;
            while(System.currentTimeMillis()<deadline) {
                byte[] buf=new byte[100];
                DatagramPacket response=new DatagramPacket(buf,buf.length);
                try{socket.receive(response);}catch(java.net.SocketTimeoutException ex){break;}
                if(!response.getAddress().isSiteLocalAddress())continue;
                String body=new String(response.getData(),response.getOffset(),
                    response.getLength(),StandardCharsets.US_ASCII);
                if(body.equals("STPC-HERE|"+token+"|V12"))
                    return response.getAddress().getHostAddress();
            }
        }
        throw new IOException("No se encontró receptor. Abre MANDO ANDROID en el PC; comprueba el firewall y la Wi-Fi.");
    }
}
