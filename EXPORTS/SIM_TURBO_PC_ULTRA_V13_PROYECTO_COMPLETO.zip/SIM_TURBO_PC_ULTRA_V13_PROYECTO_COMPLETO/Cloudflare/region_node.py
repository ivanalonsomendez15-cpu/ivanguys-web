#!/usr/bin/env python3
"""AETHER reference regional health node: no VPN, DNS, proxy, or speed boost."""
import json, os, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
HOST=os.environ.get("AETHER_HOST","127.0.0.1")
PORT=int(os.environ.get("AETHER_PORT","8787"))
NODE_ID=os.environ.get("AETHER_NODE_ID","LOCAL-TEST")
REGION=os.environ.get("AETHER_REGION","no verificada")
CITY=os.environ.get("AETHER_CITY","no verificada")
START=time.monotonic()
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.split("?",1)[0] not in ("/","/health"):
            self.send_error(404,"No encontrado");return
        data={"service":"AETHER diagnostic node","online":True,"node_id":NODE_ID,
              "declared_city":CITY,"declared_region":REGION,
              "physical_location_verified":False,
              "uptime_seconds":round(time.monotonic()-START,1),
              "time_utc":datetime.now(timezone.utc).isoformat(),
              "accelerator":False,"proxy":False,"public_dns":False}
        body=json.dumps(data,ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def log_message(self,*args): pass
if __name__=="__main__":
    print("AETHER diagnostic service at http://%s:%d/health"%(HOST,PORT))
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
