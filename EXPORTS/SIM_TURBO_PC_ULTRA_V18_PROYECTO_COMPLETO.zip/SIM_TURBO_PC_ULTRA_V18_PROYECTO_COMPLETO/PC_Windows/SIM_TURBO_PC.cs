﻿// SIM TURBO PC ULTRA V3.0 - Windows 11 - .NET Framework 4.8 (sin bibliotecas externas)
// Codigo abierto, sin elevacion ni modificaciones de registro.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using Microsoft.Win32;
using System.Runtime.InteropServices;

namespace SimTurboPC {
    public class Dashboard : Form {
        const int Port = 45721;
        readonly Color back = Color.FromArgb(9, 15, 29);
        readonly Color panel = Color.FromArgb(21, 32, 52);
        readonly Color fg = Color.FromArgb(236, 243, 255);
        readonly Color muted = Color.FromArgb(160, 181, 211);
        readonly Color cyan = Color.FromArgb(22, 217, 212);
        readonly Color green = Color.FromArgb(128, 233, 152);
        readonly Label lblSignal, lblChannel, lblDownload, lblLatency, lblPhone, lblPc, lblAdvice;
        readonly TextBox txtLog;
        readonly Button btnTest, btnScan, btnBoost, btnDetails, btnUsage;
        readonly Button btnPilot, btnUndo, btnHybrid, btnStopHybrid;
        readonly Label lblAuto, lblHybrid;
        readonly string token;
        readonly System.Windows.Forms.Timer timer;
        UdpClient receiver;
        readonly BackgroundWorker tester = new BackgroundWorker();
        string lastSignal = "-", lastBand = "-";
        int lastPct = -1, lastChannel = -1;
        int lastPhoneRssi = -999, lastPhoneFreq = 0, lastPhoneRate = 0;
        DateTime lastPhoneAt = DateTime.MinValue;
        double lastMbps = -1;
        double baselineMbps = -1;
        double lastRouterPing = -1;
        readonly string pcIp;
        readonly string logPath;
        readonly string powerBackupPath, proxyMarkerPath;
        TcpListener localProxy;
        volatile bool hybridOn = false;
        string phoneAddress = "";
        string originalProxyServer = "";
        int proxyConnectIndex = 0, activeProxyClients = 0;
        const string PowerGroup = "19cbb8fa-5279-450e-9fac-8a3d5fedd0c1";
        const string PowerSetting = "12bbebe6-58d6-4636-95bb-3217ef867c1a";
        const string ProxyRegistry = @"Software\Microsoft\Windows\CurrentVersion\Internet Settings";
        [DllImport("wininet.dll", SetLastError=true)] static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);
        string lastAdvice = "";
        int neighbors = 0;

        public Dashboard() {
            base.Text = "SIM TURBO PC ULTRA V5  |  Centro de red + FPS";
            ClientSize = new Size(1020, 934);
            MinimumSize = new Size(1020, 934);
            BackColor = back;
            ForeColor = fg;
            Font = new Font("Segoe UI", 10);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            logPath = Path.Combine(local, "SimTurboPC", "diagnosticos.txt");
            powerBackupPath = Path.Combine(local, "SimTurboPC", "wifi_power_backup.txt");
            proxyMarkerPath = Path.Combine(local, "SimTurboPC", "proxy_hibrido_activo.txt");
            RecoverProxyIfCrashed();
            byte[] key = new byte[5]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(key);
            token = BitConverter.ToString(key).Replace("-", "");
            pcIp = FindLocalIp();

            Controls.Add(Text("SIM TURBO PC", 36, 20, 520, 55, 29, fg, FontStyle.Bold));
            Controls.Add(Text("ULTRA   V3.2     |     HYPERLINK · Wi-Fi · SIM · Autopiloto", 39, 76, 700, 25, 11, cyan, FontStyle.Bold));
            Button v5Center=MakeButton("AETHER · V10 INNOVATION LAB", 759, 78, 232, cyan, Color.FromArgb(13,55,65));
            v5Center.Click += (s,e) => new PerformanceCenter().ShowDialog(this);
            Button clinicV11=MakeButton("AETHER CLINIC V18",518,78,232,cyan,Color.FromArgb(13,55,65));
                clinicV11.Click+=(s,e)=>new AetherSystemClinicV11(token,pcIp).ShowDialog(this);
                Controls.Add(Text("RED / SALUD", 39, 132, 240, 24, 10, muted, FontStyle.Bold));
            MakeCard(30, 165, 300, 155); MakeCard(360, 165, 300, 155); MakeCard(690, 165, 300, 155);
            Controls.Add(Text("SEÑAL DEL PC", 52, 184, 255, 24, 11, muted, FontStyle.Bold));
            lblSignal = Text("--", 52, 212, 250, 60, 30, fg, FontStyle.Bold); Controls.Add(lblSignal);
            lblChannel = Text("Banda --  ·  Canal --", 52, 276, 250, 30, 10, muted, FontStyle.Regular); Controls.Add(lblChannel);
            Controls.Add(Text("DESCARGA REAL", 382, 184, 255, 24, 11, muted, FontStyle.Bold));
            lblDownload = Text("Sin medir", 382, 215, 260, 55, 26, fg, FontStyle.Bold); Controls.Add(lblDownload);
            Controls.Add(Text("Prueba aproximada de 8 MB", 382, 279, 260, 30, 10, muted, FontStyle.Regular));
            Controls.Add(Text("LATENCIA A INTERNET", 712, 184, 255, 24, 11, muted, FontStyle.Bold));
            lblLatency = Text("Sin medir", 712, 215, 260, 55, 26, fg, FontStyle.Bold); Controls.Add(lblLatency);
            Controls.Add(Text("No equivale al ping de un juego", 712, 279, 265, 30, 10, muted, FontStyle.Regular));

            btnScan = MakeButton("ANALIZAR WI-FI", 30, 341, 184, cyan, Color.FromArgb(7, 35, 45));
            btnTest = MakeButton("MEDIR VELOCIDAD", 224, 341, 184, Color.FromArgb(235, 243, 255), Color.FromArgb(39, 60, 84));
            btnBoost = MakeButton("OPTIMIZAR DNS", 418, 341, 184, green, Color.FromArgb(25, 55, 48));
            btnDetails = MakeButton("TEST COMPLETO", 612, 341, 184, fg, Color.FromArgb(39, 60, 84));
            btnUsage = MakeButton("VER CONSUMO", 806, 341, 184, fg, Color.FromArgb(39, 60, 84));
            btnScan.Click += (s,e) => Scan();
            btnTest.Click += (s,e) => TestSpeed();
            btnBoost.Click += (s,e) => SafeOptimize();
            btnDetails.Click += (s,e) => Process.Start("https://speed.cloudflare.com/");
            btnUsage.Click += (s,e) => { try { Process.Start("resmon.exe"); Append("Abierto Monitor de recursos. Selecciona la pestaña Red para ver procesos con tráfico."); } catch (Exception ex) { Append("No se puede abrir resmon.exe: " + ex.Message); } };

            MakeCard(30, 412, 470, 136);
            Controls.Add(Text("COMPAÑERO ANDROID · SIN CABLES", 49, 428, 435, 24, 11, cyan, FontStyle.Bold));
            lblPc = Text("IP DEL PC: " + pcIp + "      CÓDIGO: " + token, 49, 459, 435, 29, 12, fg, FontStyle.Bold);
            Controls.Add(lblPc);
            lblPhone = Text("Móvil sin conectar. Usa la misma red Wi-Fi.", 49, 500, 430, 34, 10, muted, FontStyle.Regular);
            Controls.Add(lblPhone);
            MakeCard(519, 412, 471, 136);
            Controls.Add(Text("DIAGNÓSTICO INTELIGENTE", 540, 428, 435, 24, 11, cyan, FontStyle.Bold));
            lblAdvice = Text("Pulsa ANALIZAR WI-FI para empezar.", 540, 465, 429, 70, 10, fg, FontStyle.Regular);
            Controls.Add(lblAdvice);

            MakeCard(30, 560, 960, 170);
            Controls.Add(Text("PILOTO AUTOMÁTICO · ajustes reversibles con autorización", 49, 576, 895, 24, 12, cyan, FontStyle.Bold));
            btnPilot = MakeButton("AUTOPILOTO ON", 47, 607, 225, green, Color.FromArgb(25,55,48));
            btnUndo = MakeButton("DESHACER AJUSTES", 282, 607, 225, fg, Color.FromArgb(39,60,84));
            btnHybrid = MakeButton("AETHER-LINK V8 · WI-FI + SIM", 517, 607, 225, cyan, Color.FromArgb(7,35,45));
            btnStopHybrid = MakeButton("RECUPERAR PROXY", 752, 607, 222, fg, Color.FromArgb(39,60,84));
            btnPilot.Click += (s,e) => Autopilot();
            btnUndo.Click += (s,e) => RestorePower();
            btnHybrid.Click += (s,e) => {
                if ((DateTime.Now-lastPhoneAt).TotalSeconds>10 || string.IsNullOrEmpty(phoneAddress)) {
                    MessageBox.Show("Empareja primero el móvil con CONECTAR Y MEDIR en Android. Activa PUENTE SIM. Abre la app y deja la pantalla encendida.", "SIM TURBO V4");
                    return;
                }
                new AetherBondedDownloader(phoneAddress, token).ShowDialog(this);
            };
            btnStopHybrid.Click += (s,e) => StopHybrid();
            lblAuto = Text("AUTOPILOTO: sin aplicar · solo se toca este PC", 49, 672, 470, 38, 10, muted, FontStyle.Regular);
            lblHybrid = Text("V4: suma real para archivos HTTPS con Range. No modifica el proxy.", 523, 672, 448, 38, 10, muted, FontStyle.Regular);
            Controls.Add(lblAuto); Controls.Add(lblHybrid);
            Controls.Add(Text("REGISTRO TÉCNICO / PRUEBAS", 34, 748, 500, 25, 10, muted, FontStyle.Bold));
            txtLog = new TextBox(); txtLog.Multiline = true; txtLog.ReadOnly = true; txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.SetBounds(30, 780, 960, 122); txtLog.BackColor = Color.FromArgb(14, 23, 40);
            txtLog.ForeColor = Color.FromArgb(192, 210, 230); txtLog.BorderStyle = BorderStyle.FixedSingle;
            txtLog.Font = new Font("Consolas", 9.4f); Controls.Add(txtLog);

            tester.DoWork += (s,e) => { e.Result = PerformSpeedTest(); };
            tester.RunWorkerCompleted += (s,e) => {
                btnTest.Enabled = true;
                if (e.Error != null) { Append("Prueba de velocidad fallida: " + e.Error.Message); lblDownload.Text = "No disponible"; return; }
                var result = (SpeedResult)e.Result;
                if (result.Mbps > 0) {
                    lastMbps = result.Mbps;
                    if (baselineMbps < 0) { baselineMbps = result.Mbps; Append("Referencia de esta sesión: " + baselineMbps.ToString("0.0") + " Mb/s"); }
                    else { double change = (result.Mbps - baselineMbps) / Math.Max(baselineMbps,0.01) * 100.0; Append("Variación frente a primera prueba: " + change.ToString("+0.0;-0.0;0") + "% (puede deberse a fluctuaciones normales)"); }
                    lblDownload.Text = result.Mbps.ToString("0.0") + " Mb/s";
                    Append("Descarga: " + result.Mbps.ToString("0.0") + " Mb/s; " + result.Bytes + " bytes en " + result.Seconds.ToString("0.00") + " s");
                } else { lblDownload.Text = "No disponible"; Append("Descarga no medida: " + result.Error); }
                if (result.Ping >= 0) { lblLatency.Text = result.Ping.ToString("0") + " ms"; Append("Latencia ICMP externa: " + result.Ping.ToString("0") + " ms"); }
                else lblLatency.Text = "ICMP bloqueado";
                lastRouterPing = result.RouterPing;
                if (result.RouterPing >= 0) Append("Ping medio al router: " + result.RouterPing.ToString("0.0") + " ms (" + result.RouterSuccess + "/4 respuestas)");
                MakeAdvice();
            };
            timer = new System.Windows.Forms.Timer(); timer.Interval = 750; timer.Tick += (s,e) => PollPhone(); timer.Start();
            try { receiver = new UdpClient(Port); receiver.Client.Blocking = false; Append("Escuchando telemetría UDP en puerto " + Port + "."); }
            catch (Exception ex) { Append("No se puede abrir UDP " + Port + ": " + ex.Message); }
            Append("No se necesitan permisos de administrador. No se comparte la SIM.");
            foreach (Panel card in Controls.OfType<Panel>()) card.SendToBack();
            Scan();
        }

        Label Text(string str, int x,int y,int w,int h,float size,Color c,FontStyle style) {
            Label l = new Label(); l.Text = str; l.SetBounds(x,y,w,h); l.ForeColor = c;
            l.BackColor = ((y >= 165 && y < 320) || (y >= 412 && y < 548) || (y >= 560 && y < 730)) ? panel : Color.Transparent; l.Font = new Font("Segoe UI",size,style); l.AutoEllipsis = false;
            return l;
        }
        void MakeCard(int x,int y,int w,int h) {
            Panel p = new Panel(); p.SetBounds(x,y,w,h); p.BackColor = panel;
            Controls.Add(p); p.SendToBack();
        }
        Button MakeButton(string title,int x,int y,int w,Color c,Color b) {
            Button btn = new Button(); btn.Text = title; btn.SetBounds(x,y,w,51);
            btn.FlatStyle = FlatStyle.Flat; btn.FlatAppearance.BorderSize = 0;
            btn.BackColor = b; btn.ForeColor = c; btn.Font = new Font("Segoe UI",10,FontStyle.Bold);
            btn.Cursor = Cursors.Hand; btn.Font = new Font("Segoe UI",9,FontStyle.Bold); Controls.Add(btn); return btn;
        }
        string Run(string app,string args,int waitMs) {
            try {
                using (var p = new Process()) {
                    p.StartInfo = new ProcessStartInfo(app,args) { UseShellExecute = false, CreateNoWindow = true,
                      RedirectStandardOutput = true, RedirectStandardError = true };
                    p.Start(); string output = p.StandardOutput.ReadToEnd();
                    if (!p.WaitForExit(waitMs)) { try {p.Kill();} catch {} return "Tiempo de espera agotado"; }
                    return output;
                }
            } catch (Exception ex) { return "ERROR: " + ex.Message; }
        }
        string MatchValue(string text,string pattern) {
            Match m = Regex.Match(text,pattern,RegexOptions.Multiline|RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : "";
        }
        string FindLocalIp() {
            try {
                var list = NetworkInterface.GetAllNetworkInterfaces().Where(n=>n.OperationalStatus==OperationalStatus.Up &&
                   n.NetworkInterfaceType!=NetworkInterfaceType.Loopback).OrderBy(n => n.NetworkInterfaceType==NetworkInterfaceType.Wireless80211 ? 0 : 1);
                foreach (var ni in list) {
                    IPInterfaceProperties ip = ni.GetIPProperties();
                    if (!ip.GatewayAddresses.Any(g => g.Address.AddressFamily==AddressFamily.InterNetwork)) continue;
                    foreach(var a in ip.UnicastAddresses) if(a.Address.AddressFamily==AddressFamily.InterNetwork) return a.Address.ToString();
                }
            } catch {} return "Busca IPv4 en ipconfig";
        }
        void Append(string s) {
            string line = "[" + DateTime.Now.ToString("HH:mm:ss") + "] " + s;
            txtLog.AppendText(line + Environment.NewLine);
            try { Directory.CreateDirectory(Path.GetDirectoryName(logPath)); File.AppendAllText(logPath,line+Environment.NewLine); } catch {}
        }
        void Scan() {
            string raw = Run("netsh.exe", "wlan show interfaces", 3500);
            string pct = MatchValue(raw,@"^\s*(?:Signal|Señal)\s*:\s*(\d{1,3})\s*%");
            string chan = MatchValue(raw,@"^\s*(?:Channel|Canal)\s*:\s*(\d+)");
            string radio = MatchValue(raw,@"^\s*(?:Radio type|Tipo de radio)\s*:\s*(.+)$");
            int p, c; lastPct = int.TryParse(pct,out p) ? p : -1;
            lastChannel = int.TryParse(chan,out c) ? c : -1;
            lastBand = lastChannel > 0 ? (lastChannel <= 14 ? "2,4 GHz (probable)" : "5/6 GHz (probable)") : "No disponible";
            lastSignal = lastPct < 0 ? "Sin datos" : lastPct + " %";
            lblSignal.Text = lastSignal;
            lblChannel.Text = "Banda: " + lastBand + "  ·  Canal: " + (lastChannel < 0 ? "--" : chan);
            Append("Interfaz Wi-Fi: señal=" + lastSignal + ", canal=" + (chan==""?"desconocido":chan) + ", radio=" + (radio==""?"desconocido":radio));
            var wifi = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(n => n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 && n.OperationalStatus == OperationalStatus.Up);
            if (wifi != null) Append("Adaptador: " + wifi.Name + ", enlace indicado por Windows: " + (wifi.Speed/1000000) + " Mb/s (NO es velocidad de Internet)");
            else {
                var wire = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(n => n.NetworkInterfaceType == NetworkInterfaceType.Ethernet && n.OperationalStatus == OperationalStatus.Up);
                if (wire != null) { lblSignal.Text = "Ethernet"; lblChannel.Text = "Enlace: " + wire.Speed/1000000 + " Mb/s (no Internet)"; Append("Conexión de cable detectada: " + wire.Name); }
            }
            string networks = Run("netsh.exe","wlan show networks mode=bssid",4500);
            neighbors = 0;
            foreach (Match m in Regex.Matches(networks,@"(?im)^\s*(?:Channel|Canal)\s*:\s*(\d+)",RegexOptions.IgnoreCase)) {
                int n; if (int.TryParse(m.Groups[1].Value,out n) && n==lastChannel) neighbors++;
            }
            if (neighbors>0) neighbors--; // descuenta el AP asociado cuando aparece en el escaneo
            if (lastChannel>0) Append("Otros AP del mismo canal detectados (aprox.): " + neighbors);
            if (lastPct < 0) Append("Sin lectura de señal Wi-Fi. Si el PC usa Ethernet, es normal.");
            MakeAdvice();
        }
        void MakeAdvice() {
            List<string> advice = new List<string>();
            if (lastPct>=0 && lastPct<50) advice.Add("Señal baja en PC: acércalo al router o cambia la ubicación del adaptador.");
            else if (lastPct>=50 && lastPct<75) advice.Add("Señal intermedia: prueba a reducir obstáculos.");
            if (lastChannel>0 && lastChannel<=14) advice.Add("Red 2,4 GHz: prueba el SSID 5 GHz si tu router y PC lo permiten.");
            if (neighbors>=3) advice.Add("Hay varias redes en el mismo canal; puede haber congestión.");
            if (lastPhoneRssi > -999 && lastPct>=0) advice.Add("Móvil " + lastPhoneRssi + " dBm / PC " + lastPct + "%: escalas distintas, comparar solo tendencias.");
            if (lastRouterPing >= 25) advice.Add("Latencia elevada hasta el router: revisa red local, cables y cobertura.");
            if (lastPhoneRssi > -999 && lastPhoneRssi <= -75) advice.Add("El móvil recibe señal débil. Prueba a medir junto al PC y luego al lado del router.");
            if (lastPct>=0 && lastPct<50 && lastPhoneRssi >= -60) advice.Add("Señal móvil fuerte pero PC débil: examina ubicación/adaptador del PC.");
            if (lastMbps>0 && lastMbps<6) advice.Add("Velocidad baja: comprueba también la velocidad junto al router.");
            if (advice.Count==0) advice.Add("Sin anomalías evidentes. Mide la velocidad antes de cambiar nada.");
            lblAdvice.Text = string.Join(" ", advice.Take(2).ToArray());
            if (lastAdvice != advice[0]) { lastAdvice = advice[0]; Append("Consejo: " + advice[0]); }
        }
        void TestSpeed() {
            if (tester.IsBusy) return;
            var ask = MessageBox.Show("La prueba descargará hasta ~8 MB. Si el modo HÍBRIDO está activo, parte podría pasar por la SIM y consumir datos móviles. ¿Continuar?",
                 "SIM TURBO PC · Test de velocidad",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (ask!=DialogResult.Yes) return;
            lblDownload.Text = "Midiendo..."; lblLatency.Text = "Midiendo...";
            btnTest.Enabled = false; tester.RunWorkerAsync();
        }
        public class SpeedResult { public double Mbps=-1; public double Ping=-1; public double RouterPing=-1; public int RouterSuccess=0; public long Bytes=0; public double Seconds=0; public string Error=""; }
        SpeedResult PerformSpeedTest() {
            var r = new SpeedResult();
            try {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces().Where(n => n.OperationalStatus==OperationalStatus.Up && n.NetworkInterfaceType!=NetworkInterfaceType.Loopback)) {
                    var gateway = ni.GetIPProperties().GatewayAddresses.FirstOrDefault(g => g.Address.AddressFamily == AddressFamily.InterNetwork);
                    if (gateway == null) continue;
                    long total = 0; int count = 0;
                    using (var ping = new Ping()) {
                        for (int i=0;i<4;i++) { try { var reply=ping.Send(gateway.Address,900); if(reply.Status==IPStatus.Success) {total+=reply.RoundtripTime; count++;} } catch {} }
                    }
                    if(count>0) r.RouterPing = total/(double)count;
                    r.RouterSuccess = count; break;
                }
            } catch {}
            try { using(var p=new Ping()) { var reply=p.Send("1.1.1.1",1800); if(reply.Status==IPStatus.Success) r.Ping=reply.RoundtripTime; } } catch {}
            try {
                // Muestra de descarga acotada: 8.000.000 bytes, sin cargar el archivo en memoria.
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
                string url="https://speed.cloudflare.com/__down?bytes=8000000&nocache=" + DateTime.UtcNow.Ticks;
                HttpWebRequest req=(HttpWebRequest)WebRequest.Create(url); req.Timeout=14000; req.ReadWriteTimeout=14000;
                req.CachePolicy=new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
                req.UserAgent="SIM-TURBO-PC-ULTRA/2.0";
                Stopwatch sw=new Stopwatch(); sw.Start();
                using(var resp=(HttpWebResponse)req.GetResponse()) using (var stream=resp.GetResponseStream()) {
                    byte[] buf=new byte[65536]; int n;
                    while ((n=stream.Read(buf,0,buf.Length))>0 && r.Bytes < 8000000) r.Bytes+=n;
                }
                sw.Stop(); r.Seconds=sw.Elapsed.TotalSeconds;
                if (r.Seconds>0.01 && r.Bytes > 300000) r.Mbps=r.Bytes*8.0/(r.Seconds*1000000.0);
                else r.Error="La prueba devolvió una respuesta demasiado pequeña.";
            } catch(Exception ex) { r.Error=ex.Message; }
            return r;
        }
        void SafeOptimize() {
            var answer=MessageBox.Show("Acción segura: limpiar la caché DNS de Windows.\n\nEsto puede resolver errores de nombres, pero NO multiplica los Mb/s.\n\nNo cambia DNS, controladores, Wi-Fi, firewall, registro ni configuración del router.\n\n¿Ejecutarla?",
                "Optimización segura",MessageBoxButtons.YesNo,MessageBoxIcon.Information);
            if(answer!=DialogResult.Yes) return;
            string output=Run("ipconfig.exe","/flushdns",5000);
            Append("DNS: " + output.Trim().Replace(Environment.NewLine," "));
            MessageBox.Show("Operación terminada. Consulta el registro técnico para ver si Windows la aceptó.","SIM TURBO PC");
        }
        void PollPhone() {
            if(receiver==null) return;
            try {
                while(receiver.Available>0) {
                    IPEndPoint source = new IPEndPoint(IPAddress.Any,0);
                    string msg=Encoding.UTF8.GetString(receiver.Receive(ref source));
                    string[] bits=msg.Split('|');
                    if (bits.Length!=5 || bits[0]!="STPC2" || bits[1]!=token) continue;
                    int rssi,freq,rate;
                    if(!int.TryParse(bits[2],out rssi)||!int.TryParse(bits[3],out freq)||!int.TryParse(bits[4],out rate)) continue;
                    if(rssi < -130 || rssi > -10 || freq < 0 || freq > 7500 || rate < 0 || rate > 20000) continue;
                    lastPhoneRssi=rssi; lastPhoneFreq=freq; lastPhoneRate=rate; lastPhoneAt=DateTime.Now;
                    phoneAddress = source.Address.ToString();
                    lblPhone.Text="Móvil enlazado · " + source.Address + " · " + rssi + " dBm · " + freq + " MHz · " + rate + " Mb/s (enlace)";
                    MakeAdvice();
                }
                if(lastPhoneAt != DateTime.MinValue && (DateTime.Now-lastPhoneAt).TotalSeconds > 8)
                    lblPhone.Text="Móvil desconectado (último dato hace " + (int)(DateTime.Now-lastPhoneAt).TotalSeconds + " s)";
            } catch(SocketException) {} catch(ObjectDisposedException) {} catch(Exception ex) { Append("UDP: "+ex.Message); }
        }

        // AUTOPILOTO: ajusta solamente la gestion de energia del adaptador inalambrico
        // conectado a corriente, cuando Windows expone el parametro. Restaura el valor.
        int ReadAcPowerIndex() {
            string output = Run("powercfg.exe", "/query SCHEME_CURRENT " + PowerGroup + " " + PowerSetting, 6500);
            foreach (string line in output.Split('\n')) {
                bool ac = Regex.IsMatch(line, @"(?i)(current\s+ac|actual.{0,20}(?:ca|corriente)|\bca\b.*(?:actual|indice)|\bac\b.*(?:current|index))");
                if (!ac) continue;
                Match m = Regex.Match(line, @"0x([0-9a-fA-F]{1,8})");
                int index;
                if (m.Success && int.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.HexNumber,
                    System.Globalization.CultureInfo.InvariantCulture, out index) && index >= 0 && index <= 3) return index;
            }
            return -1;
        }
        bool PowerCfgElevated(int index) {
            try {
                var p = new Process();
                p.StartInfo = new ProcessStartInfo("cmd.exe", "/c powercfg.exe /setacvalueindex SCHEME_CURRENT " + PowerGroup + " " + PowerSetting + " " + index + " && powercfg.exe /setactive SCHEME_CURRENT") {
                    UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden
                };
                p.Start(); p.WaitForExit(12000);
                if(!p.HasExited || p.ExitCode!=0) { Append("No se completo el cambio de energia (cancelado o rechazado)."); return false; }
                return true;
            } catch (Win32Exception) { Append("Permisos de administrador no concedidos; no se cambio la configuracion."); return false; }
              catch (Exception e) { Append("Cambio de energia no disponible: " + e.Message); return false; }
        }
        void Autopilot() {
            Scan();
            string plan = "AUTOPILOTO V3 - SOLO ESTE PC\n\n1. Analizar cobertura y entorno Wi-Fi.\n" +
                "2. Limpiar cache DNS local (si Windows lo permite).\n" +
                "3. Si existe el ajuste, poner AHORRO DE ENERGIA Wi-Fi (solo con corriente) en MAXIMO RENDIMIENTO.\n" +
                "4. Guardar el valor anterior para revertirlo.\n\n" +
                "Windows puede solicitar permiso de administrador para el paso 3.\n" +
                "No cambiamos router, firewall, contrasenas, controladores ni servidores DNS.\n" +
                "No asegura mayor velocidad; puede aumentar el consumo electrico. ¿Autorizar?";
            if(MessageBox.Show(plan,"SIM TURBO V3 · AUTORIZAR",MessageBoxButtons.YesNo,MessageBoxIcon.Question)!=DialogResult.Yes) return;
            string dns = Run("ipconfig.exe", "/flushdns", 6000);
            Append("Autopiloto DNS: " + dns.Replace("\r", " ").Replace("\n", " ").Trim());
            int current = ReadAcPowerIndex();
            if(current<0) {
                lblAuto.Text="Escaneo y DNS realizados. Ajuste de energia Wi-Fi no disponible.";
                Append("No se cambia el ajuste Wi-Fi: Windows no expone valor de CA reconocible."); return;
            }
            if(current==0) { lblAuto.Text="Windows ya usa rendimiento maximo de Wi-Fi con corriente."; Append("Plan Wi-Fi ya optimizado. No se hace ningun cambio."); return; }
            if(File.Exists(powerBackupPath)) { lblAuto.Text="Existe copia de cambio anterior; primero deshazla."; return; }
            try { Directory.CreateDirectory(Path.GetDirectoryName(powerBackupPath)); File.WriteAllText(powerBackupPath,current.ToString()); }
            catch(Exception e) { Append("No se pudo respaldar la configuracion. Cancelado: "+e.Message); return; }
            if(PowerCfgElevated(0)) {
                lblAuto.Text="Wi-Fi: maximo rendimiento con corriente. Deshacer disponible.";
                Append("Ajuste energia Wi-Fi CA: " + current + " -> 0 (max rendimiento). Respaldo local guardado.");
            } else {
                // Sin confirmacion de aplicacion no se da por hecho un cambio.
                try {File.Delete(powerBackupPath);} catch {}
                lblAuto.Text="No se modifico plan Wi-Fi; comprueba permisos o soporte.";
            }
        }
        void RestorePower() {
            if(!File.Exists(powerBackupPath)) { MessageBox.Show("No hay cambios de potencia Wi-Fi pendientes de restaurar."); return; }
            int index;
            if(!int.TryParse(File.ReadAllText(powerBackupPath).Trim(),out index) || index<0 || index>3) {
                MessageBox.Show("Copia de seguridad no valida. No se realizan cambios."); return;
            }
            if(MessageBox.Show("¿Restaurar nivel Wi-Fi de energia anterior ("+index+")?","Deshacer",MessageBoxButtons.YesNo)!=DialogResult.Yes) return;
            if(PowerCfgElevated(index)) { try{File.Delete(powerBackupPath);}catch{} lblAuto.Text="Configuracion anterior restaurada."; Append("Energia Wi-Fi restaurada a " + index); }
        }
        void RecoverProxyIfCrashed() {
            if (!File.Exists(proxyMarkerPath)) return;
            try {
                string previous = File.ReadAllText(proxyMarkerPath,Encoding.UTF8);
                using(var key = Registry.CurrentUser.CreateSubKey(ProxyRegistry)) {
                    key.SetValue("ProxyEnable",0,RegistryValueKind.DWord);
                    key.SetValue("ProxyServer",previous,RegistryValueKind.String);
                }
                InternetSetOption(IntPtr.Zero,39,IntPtr.Zero,0); InternetSetOption(IntPtr.Zero,37,IntPtr.Zero,0);
                File.Delete(proxyMarkerPath);
            } catch { /* La ayuda RESTAURAR_PROXY.cmd permite desactivar manualmente. */ }
        }
        void StartHybrid() {
            if(hybridOn) return;
            if((DateTime.Now-lastPhoneAt).TotalSeconds>8 || phoneAddress=="") {
                MessageBox.Show("Abre la APK y pulsa CONECTAR Y MEDIR. Luego activa PUENTE SIM en el movil. El PC debe recibir la señal del movil antes de continuar."); return;
            }
            string warning = "HÍBRIDO EXPERIMENTAL: REPARTO DE CONEXIONES WEB, NO SUMA DE UNA MISMA DESCARGA.\n\n" +
                 "Una parte de las conexiones HTTPS de aplicaciones que usan el proxy de Windows ira por la SIM del movil; las demas por el Wi-Fi.\n" +
                 "El movil debe seguir abierto y conectado al Wi-Fi domestico Y a datos 4G/5G.\n" +
                 "CONSUMIRA DATOS MOVILES y puede agotar tu tarifa. Puede ir peor o interrumpir servicios.\n" +
                 "Temporalmente configura el proxy HTTP/HTTPS de TU SESION de Windows en 127.0.0.1:45724.\n" +
                 "Al detenerlo o cerrar el programa se restaura. Si se cierra de golpe, abre la app otra vez o ejecuta RESTAURAR_PROXY.cmd.\n" +
                 "No cambia el firewall, no instala VPN y NO afecta a juegos que ignoren el proxy.\n\n¿Activar bajo tu responsabilidad?";
            if(MessageBox.Show(warning,"SIM TURBO V3 · AUTORIZAR USO SIM",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes) return;
            try {
                using (var key=Registry.CurrentUser.OpenSubKey(ProxyRegistry,false)) {
                    if(key==null) throw new Exception("No se puede leer ajustes proxy actuales");
                    int enabled=Convert.ToInt32(key.GetValue("ProxyEnable",0));
                    string pac = Convert.ToString(key.GetValue("AutoConfigURL",""));
                    if(enabled!=0 || !String.IsNullOrEmpty(pac)) throw new Exception("Ya tienes un proxy o PAC configurado; no se modificara para evitar sobrescribirlo.");
                    originalProxyServer=Convert.ToString(key.GetValue("ProxyServer",""));
                }
                Directory.CreateDirectory(Path.GetDirectoryName(proxyMarkerPath));
                File.WriteAllText(proxyMarkerPath,originalProxyServer,Encoding.UTF8);
                localProxy=new TcpListener(IPAddress.Loopback,45724); localProxy.Start(64);
                hybridOn=true;
                ThreadPool.QueueUserWorkItem(o=>ProxyAcceptLoop());
                using(var key=Registry.CurrentUser.CreateSubKey(ProxyRegistry)) {
                    key.SetValue("ProxyServer","127.0.0.1:45724",RegistryValueKind.String);
                    key.SetValue("ProxyEnable",1,RegistryValueKind.DWord);
                }
                InternetSetOption(IntPtr.Zero,39,IntPtr.Zero,0); InternetSetOption(IntPtr.Zero,37,IntPtr.Zero,0);
                lblHybrid.Text="HÍBRIDO ON · 1 de cada 3 conexiones HTTPS -> SIM (si responde)";
                Append("Hibrido iniciado. Proxy WinINET 127.0.0.1:45724. 2/3 conexiones directas Wi-Fi, 1/3 por SIM, caidas SIM -> Wi-Fi.");
            } catch(Exception e) { Append("No se pudo iniciar hibrido: "+e.Message); StopHybrid(); MessageBox.Show("No activado: "+e.Message); }
        }
        void StopHybrid() {
            hybridOn=false;
            try {if(localProxy!=null) localProxy.Stop();} catch {} localProxy=null;
            try {
                if(File.Exists(proxyMarkerPath)) RecoverProxyIfCrashed();
            } catch(Exception e) {Append("Proxy: revision manual necesaria: "+e.Message);}
            if(lblHybrid!=null) lblHybrid.Text="HÍBRIDO OFF · la SIM ya no se utiliza desde el PC";
        }
        void ProxyAcceptLoop() {
            while(hybridOn) {
                try {
                    TcpClient incoming=localProxy.AcceptTcpClient();
                    if(Interlocked.Increment(ref activeProxyClients)>36) {Interlocked.Decrement(ref activeProxyClients); incoming.Close(); continue;}
                    ThreadPool.QueueUserWorkItem(o=> {try{HandleProxy(incoming);}catch{}finally{Interlocked.Decrement(ref activeProxyClients);incoming.Close();}});
                } catch { if (!hybridOn) break; }
            }
        }
        static string ReadAsciiLine(NetworkStream stream, int maxLen) {
            var b=new List<byte>();
            for(int i=0;i<maxLen;i++) {
                int c=stream.ReadByte(); if(c<0) throw new IOException("Conexión interrumpida");
                if(c==10) return Encoding.ASCII.GetString(b.ToArray()).TrimEnd('\r');
                if(c==13) continue;
                b.Add((byte)c);
            }
            throw new IOException("Cabecera demasiado larga");
        }
        static void Pipe(Stream from,Stream to) {
            try {var buffer=new byte[16384];int n;while((n=from.Read(buffer,0,buffer.Length))>0){to.Write(buffer,0,n);to.Flush();}}catch{}
        }
        void HandleProxy(TcpClient browser) {
            browser.ReceiveTimeout=15000; browser.SendTimeout=30000;
            NetworkStream down=browser.GetStream();
            string first=ReadAsciiLine(down,1000);
            var match=Regex.Match(first,@"^CONNECT ([a-zA-Z0-9._-]{1,250}):(443) HTTP/1\.[01]$",RegexOptions.IgnoreCase);
            int headSize=first.Length; string header;
            List<string> headers=new List<string>();
            do {header=ReadAsciiLine(down,1500);headSize+=header.Length; if(headSize>8192) throw new IOException("Cabecera demasiado larga");
                if(header.Length>0)headers.Add(header);
            } while(header.Length>0);
            if(!match.Success) {
                // Las peticiones HTTP normales deben seguir funcionando: las enviamos
                // directamente por Wi-Fi, nunca por la SIM. No altera sus contenidos.
                Match http=Regex.Match(first,@"^([A-Z]+) (http://[^ ]+) HTTP/(1\.[01])$",RegexOptions.IgnoreCase);
                Uri requested;
                if(http.Success && Uri.TryCreate(http.Groups[2].Value,UriKind.Absolute,out requested)
                      && requested.Scheme=="http" && requested.Port==80) {
                    try {
                        using(var direct=new TcpClient()) {
                            if(!direct.ConnectAsync(requested.Host,80).Wait(6500))throw new IOException("HTTP sin Wi-Fi");
                            NetworkStream outStream=direct.GetStream();
                            string path=requested.PathAndQuery;
                            if(String.IsNullOrEmpty(path))path="/";
                            string firstOrigin=http.Groups[1].Value+" "+path+" HTTP/"+http.Groups[3].Value+"\r\n";
                            byte[] intro=Encoding.ASCII.GetBytes(firstOrigin);
                            outStream.Write(intro,0,intro.Length);
                            foreach(string h in headers) {
                                if(Regex.IsMatch(h,@"^(Proxy-Authorization|Proxy-Connection|Connection):",RegexOptions.IgnoreCase))continue;
                                byte[] b=Encoding.ASCII.GetBytes(h+"\r\n");outStream.Write(b,0,b.Length);
                            }
                            byte[] end=Encoding.ASCII.GetBytes("Connection: close\r\n\r\n");
                            outStream.Write(end,0,end.Length);
                            Thread t=new Thread(()=>Pipe(outStream,down));t.IsBackground=true;t.Start();
                            Pipe(down,outStream);
                        }
                    } catch { try {byte[] err=Encoding.ASCII.GetBytes("HTTP/1.1 502 Bad Gateway\r\n\r\n");down.Write(err,0,err.Length);} catch {} }
                    return;
                }
                byte[] blocked=Encoding.ASCII.GetBytes("HTTP/1.1 405 Method Not Allowed\r\nConnection: close\r\n\r\n");
                down.Write(blocked,0,blocked.Length);return;
            }
            string host=match.Groups[1].Value;
            bool toSim=Interlocked.Increment(ref proxyConnectIndex)%3==0 && (DateTime.Now-lastPhoneAt).TotalSeconds<8;
            TcpClient uplink=null;
            try {
                if(toSim) {
                    try {
                        uplink=new TcpClient();uplink.ReceiveTimeout=12000;uplink.SendTimeout=12000;
                        if(!uplink.ConnectAsync(phoneAddress,45725).Wait(3500)) throw new IOException("SIM no responde");
                        NetworkStream feed=uplink.GetStream();
                        byte[] intro=Encoding.ASCII.GetBytes("STPC3|"+token+"|"+host+"|443\n");feed.Write(intro,0,intro.Length);
                        if(ReadAsciiLine(feed,120)!="OK") throw new IOException("APK sin puente celular");
                    } catch {if(uplink!=null)uplink.Close();uplink=null;}
                }
                if(uplink==null) { uplink=new TcpClient(); if(!uplink.ConnectAsync(host,443).Wait(7000)) throw new IOException("Wi-Fi no responde"); }
                uplink.ReceiveTimeout=0; uplink.SendTimeout=0;
                byte[] response=Encoding.ASCII.GetBytes("HTTP/1.1 200 Connection Established\r\n\r\n"); down.Write(response,0,response.Length);
                using(uplink) {
                    NetworkStream upstream=uplink.GetStream();
                    Thread t=new Thread(()=>Pipe(upstream,down));t.IsBackground=true;t.Start();
                    Pipe(down,upstream);
                }
            } catch {
                byte[] error=Encoding.ASCII.GetBytes("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n");
                try{down.Write(error,0,error.Length);}catch{}
                if(uplink!=null) uplink.Close();
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e) { StopHybrid(); if(receiver!=null) receiver.Close(); timer.Stop(); base.OnFormClosed(e); }
    }
    static class Program {
        [STAThread] static void Main() { Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new Dashboard()); }
    }
}
