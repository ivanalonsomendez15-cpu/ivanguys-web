package com.simturbopc.ultra;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.SocketTimeoutException;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Telemetría Wi-Fi local y voluntaria. No envía datos de la SIM ni crea un hotspot. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF09101E, CARD = 0xFF18263B, CYAN = 0xFF19D9D1, WHITE = 0xFFF2F7FE, GREY = 0xFFB2C4D8;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private EditText ipBox, codeBox;
    private TextView status, stats;
    private Button toggle, cellularToggle;
    private TextView cellStatus;
        private ControllerSender controllerSender;
        private boolean controllerOn = false;
        private Button controllerToggle;
        private TextView controllerStatus;
        private android.widget.EditText v12GamePackage;
        private android.widget.Spinner v12ProfileMode;
        private TextView v12Info;
        private boolean v12MonitorRequested=false;
    
    private volatile boolean cellularOn = false;
    private volatile Network cellNetwork;
    private volatile String pairedPcIp = "", pairedToken = "";
    private ServerSocket cellServer;
    private BondedServer bondedServer;
    private ConnectivityManager.NetworkCallback cellularCallback;
    private final AtomicLong simBytes = new AtomicLong(0L);
    private boolean active = false;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!active) return;
            sendOnce();
            handler.postDelayed(this, 2500);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(30), dp(20), dp(32));
        sv.addView(root);

        root.addView(text("SIM TURBO", 34, WHITE, true));
        root.addView(text("PC ULTRA  ·  HYPERLINK ANDROID V12 · MONITOR Y MANDO PC", 12, CYAN, true));
        gap(root, 26);
        root.addView(text("Enlace inalámbrico: medidor Wi-Fi + puente celular opcional", 16, WHITE, true));
        gap(root, 11);
        root.addView(text("El PC conserva su Wi-Fi. Este móvil envía mediciones y, si activas la SIM, descarga fragmentos HTTPS que el PC reúne con otros descargados por Wi-Fi. No necesita USB ni activar el punto de acceso.", 14, GREY, false));
        gap(root, 22);

        LinearLayout form = card(); root.addView(form);
        form.addView(text("EMPAREJAR CON EL PC", 15, CYAN, true));
        gap(form, 13);
        form.addView(text("Dirección IPv4 que aparece en Windows", 12, GREY, false));
        ipBox = entry("Ej.: 192.168.1.34"); form.addView(ipBox);
        gap(form, 12);
        form.addView(text("Código de 10 caracteres de Windows", 12, GREY, false));
        codeBox = entry("Ej.: A1B2C3D4E5"); form.addView(codeBox);
        gap(form, 15);
        toggle = new Button(this); toggle.setAllCaps(false); toggle.setText("CONECTAR Y MEDIR");
        toggle.setTextColor(BG); toggle.setTextSize(15); toggle.setTypeface(null, Typeface.BOLD);
        toggle.setBackground(rounded(CYAN, 14)); form.addView(toggle,
            new LinearLayout.LayoutParams(-1, dp(55)));
        toggle.setOnClickListener(v -> { if(active) stop(); else start(); });
        gap(root, 20);

        LinearLayout readings = card(); root.addView(readings);
        readings.addView(text("LECTURAS DEL MÓVIL", 15, CYAN, true));
        gap(readings, 14);
        stats = text("Sin datos todavía", 15, WHITE, false); readings.addView(stats);
        gap(readings, 10);
        status = text("Estado: desconectado", 13, GREY, false); readings.addView(status);
        gap(root, 18);
        LinearLayout cellCard = card(); root.addView(cellCard);
        cellCard.addView(text("MODO 2 · SIM REAL PARA SUMAR DESCARGAS", 15, CYAN, true));
        gap(cellCard, 10);
        cellCard.addView(text("AVISO: al activarlo se consumen datos de tu tarifa 4G/5G. Puede tener costes y calentamiento. Necesitas Wi-Fi y datos activos al mismo tiempo. La app debe permanecer abierta.", 14, GREY, false));
        gap(cellCard, 12);
        cellularToggle = new Button(this); cellularToggle.setAllCaps(false);
        cellularToggle.setText("ACTIVAR PUENTE SIM"); cellularToggle.setTextColor(BG);
        cellularToggle.setTypeface(null,Typeface.BOLD); cellularToggle.setBackground(rounded(CYAN,14));
        cellCard.addView(cellularToggle,new LinearLayout.LayoutParams(-1,dp(52)));
        gap(cellCard,8);
        cellStatus = text("Inactivo: 0 bytes transferidos por el puente.",13,GREY,false);
        cellCard.addView(cellStatus);
        cellularToggle.setOnClickListener(v -> { if(cellularOn) stopCell(); else startCell(); });
        gap(root, 18);
        LinearLayout padCard = card(); root.addView(padCard);
            padCard.addView(text("MODO 3 · MANDO ANDROID PARA PC V11", 15, CYAN, true));
            gap(padCard,10);
            padCard.addView(text("Controles por Wi-Fi local al PC emparejado. No usa datos SIM. En Windows abre AETHER CLINIC V11 > MANDO ANDROID y activa el receptor.",13,GREY,false));
            gap(padCard,12);
            controllerToggle = new Button(this);
            controllerToggle.setAllCaps(false);
            controllerToggle.setText("ACTIVAR MANDO");
            controllerToggle.setTextColor(BG);
            controllerToggle.setTypeface(null,Typeface.BOLD);
            controllerToggle.setBackground(rounded(CYAN,14));
            padCard.addView(controllerToggle,new LinearLayout.LayoutParams(-1,dp(52)));
            controllerToggle.setOnClickListener(v->{if(controllerOn)stopController();else startController();});
            gap(padCard,10);
            controllerStatus=text("Mando desconectado. Empareja primero y activa el receptor en PC.",12,GREY,false);
            padCard.addView(controllerStatus);
            gap(padCard,8);
            padCard.addView(text("CRUCETA · W / A / S / D",12,CYAN,true));
            LinearLayout dirs=new LinearLayout(this);
            dirs.setOrientation(LinearLayout.HORIZONTAL);
            addControllerButton(dirs,"↑","W");
            addControllerButton(dirs,"←","A");
            addControllerButton(dirs,"↓","S");
            addControllerButton(dirs,"→","D");
            padCard.addView(dirs);
            gap(padCard,9);
            padCard.addView(text("BOTONES · teclado configurable en cada juego",12,CYAN,true));
            LinearLayout buttons=new LinearLayout(this);
            buttons.setOrientation(LinearLayout.HORIZONTAL);
            addControllerButton(buttons,"A","SPACE");
            addControllerButton(buttons,"B","ESC");
            addControllerButton(buttons,"X","F");
            addControllerButton(buttons,"Y","E");
            padCard.addView(buttons);
            gap(padCard,8);
            LinearLayout extras=new LinearLayout(this);
            extras.setOrientation(LinearLayout.HORIZONTAL);
            addControllerButton(extras,"LB","Q");
            addControllerButton(extras,"RB","SHIFT");
            addControllerButton(extras,"START","ENTER");
            padCard.addView(extras);
            gap(root,18);
            LinearLayout aetherCard=card();root.addView(aetherCard);
        aetherCard.addView(text("AETHER V12 · MONITOR MÓVIL Y JUEGOS",15,CYAN,true));
        gap(aetherCard,9);
        aetherCard.addView(text("Servicio visible en segundo plano: batería y conexión cada 20 s. No modifica Android ni otros juegos.",12,GREY,false));
        Button monitorBtn=new Button(this);
        monitorBtn.setAllCaps(false);
        monitorBtn.setText("INICIAR MONITOR VISIBLE");
        aetherCard.addView(monitorBtn,new LinearLayout.LayoutParams(-1,dp(48)));
        monitorBtn.setOnClickListener(v->{
            try{
                android.content.Intent intent=new android.content.Intent(this,AetherMonitorService.class);
                if(!v12MonitorRequested){
                    if(android.os.Build.VERSION.SDK_INT>=33 &&
                       checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},1201);
                    if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(intent);
                    else startService(intent);
                    v12MonitorRequested=true;
                    monitorBtn.setText("DETENER MONITOR");
                    v12Info.setText("Monitor solicitado; Android puede pausarlo por batería.");
                }else{
                    stopService(intent);
                    v12MonitorRequested=false;
                    monitorBtn.setText("INICIAR MONITOR VISIBLE");
                    v12Info.setText("Monitor detenido por el usuario.");
                }
            }catch(Exception ex){v12Info.setText("No se pudo iniciar: "+ex.getMessage());}
        });
        Button sampleBtn=new Button(this);
        sampleBtn.setAllCaps(false);sampleBtn.setText("VER ÚLTIMA MUESTRA DEL MÓVIL");
        aetherCard.addView(sampleBtn,new LinearLayout.LayoutParams(-1,dp(46)));
        sampleBtn.setOnClickListener(v->v12Info.setText(
            getSharedPreferences(AetherMonitorService.PREFS,MODE_PRIVATE)
                .getString("last_status","Aún no hay muestras.")));
        gap(aetherCard,9);
        aetherCard.addView(text("PERFILES POR JUEGO · SOLO CONSEJOS, SIN MODIFICAR OTRAS APPS",12,CYAN,true));
        v12GamePackage=new android.widget.EditText(this);
        v12GamePackage.setSingleLine(true);
        v12GamePackage.setText("com.roblox.client");
        v12GamePackage.setTextColor(0xFFFFFFFF);
        v12GamePackage.setHint("Paquete Android del juego");
        aetherCard.addView(v12GamePackage,new LinearLayout.LayoutParams(-1,dp(50)));
        v12ProfileMode=new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> modes=new android.widget.ArrayAdapter<>(
            this,android.R.layout.simple_spinner_item,GameProfiles.MODES);
        modes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        v12ProfileMode.setAdapter(modes);
        aetherCard.addView(v12ProfileMode,new LinearLayout.LayoutParams(-1,dp(52)));
        Button saveGame=new Button(this);saveGame.setAllCaps(false);
        saveGame.setText("GUARDAR PERFIL DE ESTE JUEGO");
        aetherCard.addView(saveGame,new LinearLayout.LayoutParams(-1,dp(47)));
        saveGame.setOnClickListener(v->{
            try{
                String pkg=v12GamePackage.getText().toString().trim();
                String mode=String.valueOf(v12ProfileMode.getSelectedItem());
                GameProfiles.save(this,pkg,mode);
                v12Info.setText("Guardado "+pkg+" · "+mode+". "+GameProfiles.recommendation(mode));
            }catch(Exception ex){v12Info.setText("Perfil no guardado: "+ex.getMessage());}
        });
        Button lastGame=new Button(this);lastGame.setAllCaps(false);
        lastGame.setText("DETECTAR ÚLTIMO JUEGO CONFIGURADO");
        aetherCard.addView(lastGame,new LinearLayout.LayoutParams(-1,dp(47)));
        lastGame.setOnClickListener(v->{
            if(!GameProfiles.hasUsageAccess(this)){
                v12Info.setText("Concede Acceso a datos de uso a AETHER si deseas detección voluntaria.");
                startActivity(new android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));
            }else{
                String pkg=GameProfiles.lastConfiguredGame(this,600000L);
                if(pkg!=null){
                    v12GamePackage.setText(pkg);
                    v12Info.setText("Detectado: "+pkg+" · "+GameProfiles.profile(this,pkg));
                }else v12Info.setText("No hay juego configurado detectado en los últimos 10 min.");
            }
        });
        gap(aetherCard,9);
        aetherCard.addView(text("PC · DETECCIÓN Y PERFIL POR HARDWARE",12,CYAN,true));
        Button findPc=new Button(this);findPc.setAllCaps(false);
        findPc.setText("DETECTAR PC POR WI-FI LOCAL");
        aetherCard.addView(findPc,new LinearLayout.LayoutParams(-1,dp(47)));
        findPc.setOnClickListener(v->{
            v12Info.setText("Buscando receptor en la LAN...");
            new Thread(()->{
                try{
                    String ip=PcDiscovery.find(this);
                    runOnUiThread(()->{
                        pairedPcIp=ip;
                        v12Info.setText("PC encontrado: "+ip+
                            ". Introduce ese IP y tu código en CONECTAR Y MEDIR para autorizarlo.");
                    });
                }catch(Exception ex){
                    runOnUiThread(()->v12Info.setText("Detección: "+ex.getMessage()));
                }
            }).start();
        });
        Button pcCaps=new Button(this);pcCaps.setAllCaps(false);
        pcCaps.setText("LEER CPU / RAM / GPU DEL PC EMPAREJADO");
        aetherCard.addView(pcCaps,new LinearLayout.LayoutParams(-1,dp(47)));
        pcCaps.setOnClickListener(v->{
            v12Info.setText("Consultando hardware con el código de emparejamiento...");
            new Thread(()->{
                try{
                    String caps=PcDiscovery.capabilities(this,pairedPcIp,pairedToken);
                    runOnUiThread(()->v12Info.setText(caps+
                        ". Recomendaciones: GPU modesta = bajar resolución y sombras; "+
                        "compara FPS reales antes y después."));
                }catch(Exception ex){
                    runOnUiThread(()->v12Info.setText("Hardware: "+ex.getMessage()));
                }
            }).start();
        });
        v12Info=text("Todo queda local. Abre el receptor V12 en Windows para detectar PC. "+
            "Los permisos de uso son opcionales.",12,GREY,false);
        aetherCard.addView(v12Info);
        gap(root,18);
        root.addView(text("PRIVACIDAD Y LÍMITES", 12, CYAN, true));
        gap(root, 8);
        root.addView(text("• Telemetría Wi-Fi sin ubicación GPS, SSID ni contraseñas.\n• El puente SIM es opcional: solo abre conexiones HTTPS (puerto 443) solicitadas desde el PC emparejado, con código local.\n• El tráfico entre PC y móvil viaja por la red doméstica; usa Wi-Fi de confianza.\n• La SIM consume datos. La suma V4 sirve para archivos HTTPS con rangos, no acelera todos los juegos ni Windows.\n• Se detiene al salir de la app. No desactiva ningún cortafuegos.", 13, GREY, false));
        setContentView(sv);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION }, 203);
    }

    private void startController() {
            if(!active) {
                controllerStatus.setText("Primero pulsa CONECTAR Y MEDIR.");
                return;
            }
            try {
                controllerSender=new ControllerSender(this,pairedPcIp,pairedToken);
                controllerOn=true;
                controllerToggle.setText("DETENER MANDO");
                controllerToggle.setBackground(rounded(0xFFFE8196,14));
                controllerStatus.setText("Mando activo: el PC debe abrir el receptor V11. Mantén pulsado para mover.");
            }catch(Exception ex){
                controllerOn=false;
                controllerSender=null;
                controllerStatus.setText("No se pudo conectar el mando: "+ex.getMessage());
            }
        }
        private void stopController() {
            controllerOn=false;
            if(controllerSender!=null){
                controllerSender.close();
                controllerSender=null;
            }
            if(controllerToggle!=null){
                controllerToggle.setText("ACTIVAR MANDO");
                controllerToggle.setBackground(rounded(CYAN,14));
            }
            if(controllerStatus!=null)controllerStatus.setText("Mando detenido. No se envían teclas.");
        }
        private void addControllerButton(LinearLayout parent,String label,String key) {
            Button btn=new Button(this);
            btn.setAllCaps(false);
            btn.setText(label);
            btn.setTextSize(17);
            btn.setTypeface(null,Typeface.BOLD);
            btn.setTextColor(BG);
            btn.setBackground(rounded(CYAN,12));
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,dp(66),1f);
            params.setMargins(dp(2),dp(3),dp(2),dp(3));
            parent.addView(btn,params);
            btn.setOnTouchListener((v,event)->{
                int action=event.getActionMasked();
                if(action==MotionEvent.ACTION_DOWN){
                    if(controllerOn&&controllerSender!=null)controllerSender.down(key);
                    return true;
                }
                if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
                    if(controllerOn&&controllerSender!=null)controllerSender.up(key);
                    return true;
                }
                return true;
            });
        }

        private void start() {
        final String ip = ipBox.getText().toString().trim();
        final String code = codeBox.getText().toString().trim().toUpperCase(Locale.ROOT);
        if (!ip.matches("[0-9.]{7,15}") || !code.matches("[0-9A-F]{10}")) {
            status.setText("Introduce una IP local IPv4 válida y el código del PC (10 caracteres)."); return;
        }
        try {
            InetAddress addr = InetAddress.getByName(ip);
            if (!addr.isSiteLocalAddress()) { status.setText("Por seguridad, solo direcciones privadas del hogar (LAN)."); return; }
        } catch (Exception ex) { status.setText("La dirección IP no es válida."); return; }
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if (findWifi(cm) == null) { status.setText("Conecta este móvil al mismo Wi-Fi que el PC."); return; }
        pairedPcIp = ip; pairedToken = code;
        active = true; toggle.setText("DESCONECTAR");
        toggle.setBackground(rounded(0xFFFE8196, 14));
        ipBox.setEnabled(false); codeBox.setEnabled(false);
        status.setText("Enviando por Wi-Fi local cada 2,5 segundos...");
        handler.post(tick);
    }
    private void stop() {
        stopController();
        stopCell();
        active = false; handler.removeCallbacks(tick);
        toggle.setText("CONECTAR Y MEDIR"); toggle.setBackground(rounded(CYAN, 14));
        ipBox.setEnabled(true); codeBox.setEnabled(true);
        status.setText("Desconectado. No se están enviando datos.");
    }
    @Override protected void onStop() { stop(); super.onStop(); }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); super.onDestroy(); }

    private Network findWifi(ConnectivityManager cm) {
        if (cm == null) return null;
        for (Network n : cm.getAllNetworks()) {
            NetworkCapabilities cap = cm.getNetworkCapabilities(n);
            if (cap != null && cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return n;
        }
        return null;
    }
    private void sendOnce() {
        WifiManager wifi = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifi == null ? null : wifi.getConnectionInfo();
        int rssi = info == null ? -127 : info.getRssi();
        int freq = info == null ? 0 : info.getFrequency();
        int rate = info == null ? 0 : Math.max(0,info.getLinkSpeed());
        stats.setText("Señal: " + rssi + " dBm\nFrecuencia: " + freq + " MHz\nEnlace del móvil: " + rate + " Mb/s (no es Internet)");
        final String ip = ipBox.getText().toString().trim();
        final String code = codeBox.getText().toString().trim().toUpperCase(Locale.ROOT);
        final String packet = "STPC2|" + code + "|" + rssi + "|" + freq + "|" + rate;
        new Thread(() -> {
            try {
                ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                Network network = findWifi(cm);
                if (network == null) throw new Exception("No hay conexión Wi-Fi");
                try (DatagramSocket s = new DatagramSocket()) {
                    network.bindSocket(s); // No utiliza la SIM ni los datos móviles.
                    byte[] b = packet.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket datagram = new DatagramPacket(b,b.length,InetAddress.getByName(ip),45721);
                    s.send(datagram);
                }
                runOnUiThread(() -> { if(active) status.setText("Mediciones enviadas por Wi-Fi al PC. Comprueba Windows."); });
            } catch (Exception e) {
                final String error = e.getMessage();
                runOnUiThread(() -> { if(active) status.setText("Envío fallido: " + error + ". Revisa IP y firewall privado."); });
            }
        }).start();
    }

    private void startCell() {
        if(!active) {cellStatus.setText("Primero pulsa CONECTAR Y MEDIR y empareja el PC.");return;}
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(findWifi(cm)==null) {cellStatus.setText("El Wi-Fi local debe estar conectado.");return;}
        new android.app.AlertDialog.Builder(this)
          .setTitle("Autorizar consumo de datos SIM")
          .setMessage("Esta función usa 4G/5G real y puede gastar muchos datos móviles de tu tarifa, además de batería. No duplica antenas ni garantiza velocidad. El PC podrá usarla para parte del tráfico web HTTPS mientras la app esté abierta. ¿Activar?")
          .setNegativeButton("Cancelar",(d,w)->{})
          .setPositiveButton("ACTIVAR",(d,w)->launchCell())
          .show();
    }
    private void launchCell() {
        if(cellularOn)return;
        cellularOn=true;
        cellularToggle.setText("DETENER PUENTE SIM");
        cellularToggle.setBackground(rounded(0xFFFE8196,14));
        cellStatus.setText("Pidiendo conexión celular a Android...");
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null){stopCell();return;}
        cellularCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                if(!cellularOn)return;
                cellNetwork=network;
                runOnUiThread(()->cellStatus.setText("SIM disponible. Puente TCP local en puerto 45725. Datos: "+simBytes.get()+" B"));
            }
            @Override public void onLost(Network network) {
                if(network.equals(cellNetwork)) { cellNetwork=null; runOnUiThread(()->cellStatus.setText("SIM sin acceso. Tráfico volverá al Wi-Fi del PC.")); }
            }
        };
        NetworkRequest request=new NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build();
        try {cm.requestNetwork(request,cellularCallback);} catch(Exception e) { cellStatus.setText("No se puede solicitar red celular: "+e.getMessage());stopCell();return; }
        bondedServer = new BondedServer(pairedPcIp, pairedToken,
            () -> cellNetwork,
            line -> { if(cellularOn)cellStatus.setText(line); });
        bondedServer.start();
        new Thread(()->{
            try(ServerSocket server=new ServerSocket()) {
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress("0.0.0.0",45725),8);
                cellServer=server;
                while(cellularOn) {
                    Socket incoming=server.accept();
                    new Thread(()->serveCell(incoming),"sim-turbo-relay").start();
                }
            } catch(Exception e) {
                if(cellularOn)runOnUiThread(()->cellStatus.setText("Error en puente local: "+e.getMessage()));
            } finally {cellServer=null;}
        },"sim-turbo-accept").start();
    }
    private void stopCell() {
        if(bondedServer!=null) {bondedServer.stop();bondedServer=null;}
        cellularOn=false;cellNetwork=null;
        try{if(cellServer!=null)cellServer.close();}catch(Exception ignored){}
        try {if(cellularCallback!=null) {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm!=null)cm.unregisterNetworkCallback(cellularCallback);
        }}catch(Exception ignored){}
        cellularCallback=null;
        if(cellularToggle!=null){cellularToggle.setText("ACTIVAR PUENTE SIM");cellularToggle.setBackground(rounded(CYAN,14));}
        if(cellStatus!=null) cellStatus.setText("Puente SIM detenido. Bytes contados: "+simBytes.get());
    }
    private static String readLine(InputStream in,int max) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        for(int n=0;n<max;n++){
            int c=in.read();if(c<0)throw new IOException("Sin cabecera");
            if(c=='\n') return b.toString("US-ASCII").trim();
            if(c!='\r')b.write(c);
        }
        throw new IOException("Mensaje demasiado largo");
    }
    private void serveCell(Socket incoming) {
        try(Socket pc=incoming){
            if(!cellularOn || !pc.getInetAddress().isSiteLocalAddress())return;
            String expectedIp=pairedPcIp;
            if(!pc.getInetAddress().getHostAddress().equals(expectedIp)) return;
            pc.setSoTimeout(15000);
            InputStream input=pc.getInputStream();OutputStream output=pc.getOutputStream();
            String line=readLine(input,900);
            String[] parts=line.split("\\|",4);
            if(parts.length!=4 || !parts[0].equals("STPC3") ||
                  !parts[1].equalsIgnoreCase(pairedToken) ||
                  !parts[2].matches("[A-Za-z0-9._-]{1,250}") || !parts[3].equals("443"))return;
            Network network=cellNetwork;
            if(network==null) { output.write("ERR\n".getBytes(StandardCharsets.US_ASCII));return;}
            InetAddress[] hosts=network.getAllByName(parts[2]);
            if(hosts.length==0)throw new IOException("No se resuelve el dominio");
            try(Socket remote=network.getSocketFactory().createSocket()) {
                remote.connect(new InetSocketAddress(hosts[0],443),7000);
                output.write("OK\n".getBytes(StandardCharsets.US_ASCII));output.flush();
                pc.setSoTimeout(0);
                Thread downstream=new Thread(()->pipeCount(remote,pc));
                downstream.setDaemon(true);downstream.start();
                pipeCount(pc,remote);
            }
        }catch(Exception ignored){}
    }
    private void pipeCount(Socket from,Socket to) {
        try {
            InputStream ins=from.getInputStream();OutputStream outs=to.getOutputStream();
            byte[] b=new byte[16384];int n;
            while(cellularOn && (n=ins.read(b))>0){outs.write(b,0,n);outs.flush();long used=simBytes.addAndGet(n);
                if(used%262144<n)runOnUiThread(()->{if(cellularOn)cellStatus.setText("Puente SIM activo · transferencia: "+(simBytes.get()/1048576.0)+" MiB");});
            }
        }catch(Exception ignored){}
    }

    private int dp(int n) { return (int)(getResources().getDisplayMetrics().density*n+0.5f); }
    private void gap(LinearLayout x,int h) { View v = new View(this); x.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private GradientDrawable rounded(int color,int r) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(r)); return d;
    }
    private LinearLayout card() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(17),dp(18),dp(17),dp(20)); l.setBackground(rounded(CARD,17)); return l;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(null,Typeface.BOLD); return v;
    }
    private EditText entry(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(16); e.setHint(hint);
        e.setTextColor(WHITE); e.setHintTextColor(0xFF7991A8); e.setPadding(dp(14),dp(12),dp(14),dp(12));
        e.setBackground(rounded(0xFF0B1526,10)); return e;
    }
}
