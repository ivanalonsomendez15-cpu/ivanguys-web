@echo off
rem Uso: SOLO si SIM TURBO PC cerro de golpe y el navegador se quedo sin conexion.
rem La app nunca activa Hibrido cuando ya existe un proxy previo.
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f
echo Proxy manual desactivado para este usuario.
echo Reinicia el navegador para aplicar el cambio si fuese necesario.
pause
